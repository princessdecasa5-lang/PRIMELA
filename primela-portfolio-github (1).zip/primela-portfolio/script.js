// Mobile navigation, portfolio filters, current year, and contact email helper.
const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
  });

  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.setAttribute("aria-label", "Open navigation menu");
    });
  });
}

document.querySelectorAll(".filter-btn").forEach((button) => {
  button.addEventListener("click", () => {
    const filter = button.dataset.filter;
    document.querySelectorAll(".filter-btn").forEach((item) => {
      item.classList.toggle("active", item === button);
    });
    document.querySelectorAll(".project-card").forEach((card) => {
      card.hidden = filter !== "all" && card.dataset.category !== filter;
    });
  });
});

const year = document.getElementById("year");
if (year) year.textContent = new Date().getFullYear();

const contactForm = document.getElementById("contact-form");
const formStatus = document.getElementById("form-status");
if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(contactForm);
    const name = String(formData.get("name") || "").trim();
    const email = String(formData.get("email") || "").trim();
    const service = String(formData.get("service") || "").trim();
    const message = String(formData.get("message") || "").trim();

    // TODO: Replace with your real email address before publishing.
    const recipient = "your.email@example.com";
    const subject = encodeURIComponent(`Portfolio inquiry — ${service}`);
    const body = encodeURIComponent(
      `Hi Princess,\n\n${message}\n\nService: ${service}\nFrom: ${name}\nReply email: ${email}`
    );

    if (recipient === "your.email@example.com") {
      formStatus.textContent = "Before publishing, replace your.email@example.com in index.html and script.js with your real email address.";
    } else {
      formStatus.textContent = "Opening your email app…";
    }
    window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;
  });
}
